# Asset licence notes
Phase 1 uses **no third-party assets**: all geometry is procedural and all sounds are generated in code.
When you add assets, record: file, source URL, author, licence, whether attribution is required.
