# THE HOLLOW FLOORS

First-person psychological horror. You wake up in an abandoned apartment building. Every elevator ride changes the building.

**Status: Phase 1 (playable foundation).** Written for Godot 4.7, Compatibility renderer, GDScript.
> **Not yet run in Godot by the author** (no Godot was available when this was generated). Expect to fix a few small errors on first launch; see `tests/README.md` and `docs/DEBUGGING.md`.

## Run it
1. Install Godot 4.7 (standard version, no .NET needed).
2. Godot Project Manager > **Import** > select `project.godot`.
3. Wait for the first import/scan to finish (this registers the `class_name` scripts). If you see "Identifier not found" errors, use **Project > Reload Current Project** once.
4. Press **F5**.

## Controls
| Key | Action |
|---|---|
| W A S D | Move |
| Mouse | Look |
| Shift | Sprint (forward only) |
| Ctrl or C | Crouch (hold) |
| Space | Jump |
| E | Interact |
| F | Flashlight |
| Esc | Pause / settings |
| F3 | Developer panel (editor/debug runs only) |

## Goal of Phase 1
Walk the corridor, open doors, read the note, step into the elevator, press the button, and arrive in a different **reality** (Normal -> Distorted -> Impossible -> ...).

## What exists / what does not
Implemented: player, flashlight, interaction framework, doors, elevator state machine, RealityManager, three realities, HUD, pause + basic settings, debug panel, content validation.
**Not implemented yet** (so no docs for them): atmosphere polish & audio events (Phase 2), enemies (3), inventory/puzzles/objectives/save/endings (4), polish (5).

## Docs
Start with `docs/START_HERE.md`. Adding content now: `docs/ADD_A_REALITY.md`, `docs/ADD_AN_INTERACTABLE.md`.
