# START HERE (beginner guide)

## How the project is organised
- `scripts/` - all code, grouped by job (`player`, `world`, `interaction`, `ui`, `debug`, `core`, `audio`, `settings`).
- `resources/` - **data you edit in the Inspector, no code**: `realities/`, `floors/`, `config/player_settings.tres`.
- `scenes/` - `main/main.tscn` (the game), `player/player.tscn`.
- `docs/` - these guides. `tests/` - checklist and a headless test script.

## Safe things to edit (no coding)
| I want to... | Open this | How |
|---|---|---|
| Walk faster, change mouse feel, interaction range, jump | `resources/config/player_settings.tres` | Double-click, edit in Inspector |
| Change a reality's colours, fog, length, doors, lights, note | `resources/realities/*.tres` | Inspector |
| Add a reality | duplicate a file in `resources/realities/` | `docs/ADD_A_REALITY.md` |
| Change flashlight brightness/range/battery | `scenes/player/player.tscn` > select `Flashlight` | Inspector |
| Change elevator speed / door time / shake | `scenes/main/main.tscn` > `World/Elevator` | Inspector |
| Change keys | `scripts/settings/game_settings.gd` (`INPUT_ACTIONS`) | edit the list |
| Change base look (tonemap, glow) | `main.tscn` > `World/Atmosphere` > Environment | Inspector |

## Needs coding
New kinds of interactable object (`docs/ADD_AN_INTERACTABLE.md`), new door modes, new room shapes in `floor_builder.gd`, new debug tools.

## Back up before experimenting
Use Git: `git init`, `git add .`, `git commit -m "Phase 1"`. If something breaks: `git restore .` (undo uncommitted changes). Without Git, copy the whole folder.

## Test a change
Press F5, then follow `tests/test_checklist.md`. Press F3 to see FPS, ids and validation errors.
