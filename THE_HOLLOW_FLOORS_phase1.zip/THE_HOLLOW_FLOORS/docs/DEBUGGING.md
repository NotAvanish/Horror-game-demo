# Debugging

## Developer panel (F3)
Available in editor/debug runs. In release builds it stays off unless `[dev] enabled=true` is added to `user://settings.cfg`. Opening it frees the mouse and freezes the player.
| Feature | Notes |
|---|---|
| Info block | FPS, draw calls, memory, floor id, reality id, elevator state, player position, object you look at, story flags, ride count |
| Reality buttons | Instantly switch reality and teleport to `start` (blocked while the elevator is moving) |
| Teleport | Any registered spawn (incl. `room_NN`, `elevator_cab`) |
| Reset test run | Clears flags, reloads the floor's starting reality |
| Reload level | Reloads the whole scene |
| Test message | Checks HUD messages |
| Content errors | Everything `ContentRegistry` rejected |
Any tool use sets `GameState.debug_session = true`; there is no save system yet, and Phase 4 must refuse saving while it is true.
Not implemented yet: ray gizmo drawing, collision/navigation visualisation, item/objective tools (those systems do not exist yet).

## Common problems
| Symptom | Likely cause / fix |
|---|---|
| "Identifier not found: Door/Elevator/..." on first open | Class cache not built: wait for import, then Project > Reload Current Project |
| Black screen, message "Cannot start: floor ..." | A `.tres` in `resources/` failed validation; read Output panel / F3 |
| Fell through floor at start | Spawn validation failed; read Output ("spawn ... blocked/no floor") |
| Elevator "shudders and goes back" | The destination reality produced an invalid required spawn; the error names it |
| Mouse stuck visible | Click the game window |
| Fog looks wrong | Compatibility renderer fog is simple; tweak `fog_density` per reality |

## Reproducing a bug
Note the reality id, the spawn you used and the elevator state (F3). Use "Reset test run", teleport, repeat. Fixed seeds: `FloorDefinition.random_seed`.
