# Floors (Phase 1 status)

Only **one floor** exists: `floor_apartment_01`. In Phase 1 a floor is a `FloorDefinition` resource + the procedural `FloorBuilder`; hand-made floor scenes and multi-floor travel come in Phase 4 (`scene_path` is reserved but unused).

What you can do now: duplicate `resources/floors/floor_apartment_01.tres`, give it a new unique `id`, and edit allowed realities / start reality / required spawns / selection mode. `Main.floor_id` (Inspector on `Main`) chooses which floor starts. The registry validates the references.
