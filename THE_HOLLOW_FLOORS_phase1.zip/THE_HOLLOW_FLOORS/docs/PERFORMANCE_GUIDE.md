# Performance (Phase 1)

**Nothing here has been profiled yet.** The 30 FPS goal for a 4 GB / integrated-GPU laptop is a target, not a measured result. Measure with F3 (FPS, draw calls) and the Godot Profiler / Monitors tab.

Design choices already made: Compatibility renderer; box collision only; no shadows (flashlight and omni lights); floor/ceiling split into 6 m tiles so few lights touch each mesh; light count capped per reality (`max_corridor_lights`); cached materials/meshes/shapes; the old floor is freed on every rebuild (only one reality in memory); no post-processing.

If it is slow: lower `max_corridor_lights`, lower `fog_density` or disable fog (`fog_enabled`), reduce `clutter_count`, shorten `corridor_length`, avoid `huge_room` doors.
Known cost: each box is its own node/draw call (no MultiMesh batching yet), and flicker lights run `_process`.
