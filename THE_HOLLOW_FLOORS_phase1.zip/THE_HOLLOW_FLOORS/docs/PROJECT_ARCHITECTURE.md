# Project architecture (Phase 1)

## Autoloads (global singletons - only these five)
| Name | Job |
|---|---|
| `EventBus` | Global messages (HUD text). |
| `GameSettings` | User preferences, registers all input actions, master volume. |
| `ContentRegistry` | Loads + validates `RealityDefinition`/`FloorDefinition` `.tres` files by stable string id. |
| `GameState` | Story flags, ride counter, debug-session marker. |
| `RealityManager` | Current reality, picking the next one, transition protocol + signals. |

## Scene tree (`main.tscn`)
```
Main (main.gd: wiring only)
├ World (game_world.gd)
│  ├ Atmosphere (WorldEnvironment, reality_atmosphere.gd)
│  ├ FloorBuilder (floor_builder.gd)  <- rebuilt per reality
│  └ Elevator (elevator.gd)           <- permanent
├ Player (player.tscn)
│  └ Head/Camera3D ├ InteractionSensor └ Flashlight
├ HUD   ├ Fader   ├ PauseMenu   └ DebugPanel
```
Cross-references use exported node references set in `main.tscn` or injection from `Main`, not hard-coded paths.

## Data flow: one elevator ride
1. Player looks at the panel (`InteractionSensor` -> `target_changed`), presses E -> `Interactable.interact()`.
2. `ElevatorPanel.interacted` -> `Elevator.request_travel()`: state `OPEN -> CLOSING`, `RealityManager.begin_transition(dest)` (emits `transition_started`).
3. Doors close -> `TRAVELLING`; `ScreenFader` goes black; camera shakes.
4. `RealityManager.commit_transition()` emits `reality_applied(definition)`.
5. `GameWorld` hears it: `RealityAtmosphere.apply()` + `FloorBuilder.build()` (new corridor, doors, spawns).
6. Elevator waits two physics frames, calls `GameWorld.validate_required_spawns()`.
   - OK: later `finish_transition()` -> `transition_finished`.
   - Not OK: state `FAILED`, `fail_transition()` rolls back to the previous reality, message shown.
7. Doors open (`OPENING -> OPEN`), fade in.

## Elevator state machine
`OPEN -> CLOSING -> TRAVELLING -> OPENING -> OPEN`, with `CLOSING/TRAVELLING -> FAILED -> OPENING`. Illegal transitions are rejected and logged (`ALLOWED_TRANSITIONS` in `elevator.gd`). Requests are only accepted in `OPEN`.

## Resources
- `RealityDefinition` - everything about one reality (layout, colours, lights, fog, props, note, flags).
- `FloorDefinition` - allowed realities, start reality, required spawns, selection mode (SEQUENCE or SEEDED_RANDOM) and seed.
- `PlayerSettings` - all player tuning numbers.

## Collision layers
1 = solid world, 2 = interactable (bodies have 1+2), 4 = player. The interaction ray masks 1+2.

## Spawn ids (Marker3D)
`start`, `corridor_mid`, `corridor_end`, `room_NN` (built per reality), `elevator_cab` (permanent).

## Extension points
New reality = `.tres`. New interactable = subclass `Interactable`. New settings = `GameSettings` + one line in `pause_menu.gd`. New debug tool = one button in `debug_panel.gd`. Scripted reality order: `RealityManager.scripted_queue.append("impossible")`.
