# Replacing placeholders (Phase 1 status)

**Sounds:** all sounds are generated in code (`scripts/audio/placeholder_sounds.gd`). To use real audio, import a `.ogg`/`.wav` into `assets/audio/` and drag it onto the exported slot: `Flashlight.toggle_sound` (player.tscn), `Elevator.ding_sound / close_sound / rumble_sound` (main.tscn). Door sounds (`Door.open_sound` etc.) are set per door instance; a global audio-event system arrives in Phase 2.

**Materials/models:** walls, floors and props are coloured boxes (`GeometryUtil.material`). Colours come from the reality `.tres`. To use textured materials, edit `GeometryUtil.material()` to load a `StandardMaterial3D` from `assets/materials/`. Real models for doors/rooms arrive with hand-built scenes in Phase 4.

Assets must be free to use; record each one in `LICENSE_ASSET_NOTES.md`.
