# Add an interactable (small code)

Contract (`scripts/interaction/interactable.gd`): `can_interact(actor)`, `interact(actor)`, `get_interaction_text()`, signal `interacted`.

Example: a lamp that toggles.
```gdscript
class_name Lamp
extends Interactable

var _on := false

func _ready() -> void:
	GeometryUtil.add_visual_box(self, Vector3(0.3, 0.3, 0.3), Vector3.ZERO, GeometryUtil.material(Color.WHITE))
	GeometryUtil.add_collision_box(self, Vector3(0.3, 0.3, 0.3), Vector3.ZERO)

func get_interaction_text() -> String:
	return "Turn off lamp" if _on else "Turn on lamp"

func interact(actor: Node) -> void:
	_on = not _on
	super.interact(actor)   # emits `interacted`
```
Save as `scripts/interaction/lamp.gd`, then create it with `Lamp.new()` and `add_child()` (see how `floor_builder.gd` creates `ReadableNote`), or add a node in a scene and attach the script (it extends `StaticBody3D`).

Rules: never edit `player_controller.gd` for this. Show feedback with `EventBus.show_message()`. Keep the base collision layers (set in `Interactable._init`).
