# Add a reality (no code)

1. In the FileSystem dock open `resources/realities/`, right-click `normal.tres` > **Duplicate**, name it e.g. `flooded.tres`.
2. Double-click it. **Change `id` to a new unique value** (e.g. `flooded`) - ids are what everything refers to.
3. Edit layout, colours, lights, fog, `note_text`. Rules checked automatically:
   - `apartment_numbers` and `door_modes` must have the **same length**.
   - door modes: `open_room`, `huge_room`, `locked`.
   - doors need `first_door_offset + (count-1)*door_spacing + 1.5 <= corridor_length`.
   - `corridor_width >= 2.6`, `ceiling_height >= 2.6`.
4. Open `resources/floors/floor_apartment_01.tres` and add `"flooded"` to `allowed_reality_ids`.
5. Press F5. The elevator now includes it (SEQUENCE order follows `sequence_order`).
6. Test instantly: F3 > click the reality button.

If a file is wrong you get a clear message in the Output panel and in the F3 panel ("CONTENT ERRORS"); the broken reality is skipped, not silently half-loaded.

Force a scripted order from code: `RealityManager.scripted_queue.append("flooded")`.
Reproducible random order: set the floor's `selection_mode` to `SEEDED_RANDOM` and `random_seed` to a non-zero number.
