# Changelog

## Phase 1 - Playable foundation (unreleased, untested in-engine)
Added: player controller, flashlight, interaction framework, hinged doors, elevator state machine, RealityManager with 3 data-driven realities, procedural floor builder, HUD, pause menu with basic settings, F3 debug panel, content registry + validation, placeholder generated sounds, docs, headless content test script.
Known limitations: single floor; placeholder geometry/audio; no save/load; no enemies/inventory/puzzles/objectives.
