# Tests

**Status: written, NOT executed.** No Godot was available when these were produced, so nothing has been run.

- `automated/run_tests.gd` - headless content tests (registry loads, validation catches bad data).
  `godot --headless --path . --script res://tests/automated/run_tests.gd`
  It may need small fixes on first run (it was never compiled).
- `test_checklist.md` - manual gameplay checklist.

Automated tests for reality transitions, inventory, puzzles, objectives and save/load arrive with those systems.
