extends SceneTree
## Headless content tests (NOT yet executed by the author - see tests/README.md).
## Run:  godot --headless --path . --script res://tests/automated/run_tests.gd
## Exit code 0 = all passed, 1 = failures. Checks only data/validation logic that does
## not need the autoloads or a running scene.

var _failures := 0

func _initialize() -> void:
	var registry = load("res://scripts/core/content_registry.gd").new()
	registry.reload()
	_check(registry.errors.is_empty(), "content loads with no errors: %s" % [registry.errors])
	_check(registry.realities.size() >= 3, "at least 3 realities registered (%d)" % registry.realities.size())
	for id in ["normal", "distorted", "impossible"]:
		_check(registry.realities.has(id), "reality '%s' is registered" % id)
	_check(registry.floors.has("floor_apartment_01"), "floor_apartment_01 registered")

	# Invalid data must be rejected with messages, not accepted silently.
	var bad := RealityDefinition.new()
	bad.id = "bad"
	bad.apartment_numbers = PackedStringArray(["1", "2"])
	bad.door_modes = PackedStringArray(["open_room"])
	_check(not bad.validate().is_empty(), "mismatched door arrays are rejected")
	bad.door_modes = PackedStringArray(["open_room", "teleporter"])
	_check(not bad.validate().is_empty(), "unknown door mode is rejected")
	var nameless := RealityDefinition.new()
	_check(not nameless.validate().is_empty(), "empty id is rejected")

	var floor_def := FloorDefinition.new()
	floor_def.id = "f"
	_check(not floor_def.validate().is_empty(), "floor without realities is rejected")

	registry.free()
	print("\n%s (%d failure(s))" % ["PASSED" if _failures == 0 else "FAILED", _failures])
	quit(0 if _failures == 0 else 1)

func _check(condition: bool, label: String) -> void:
	if condition:
		print("  ok   - " + label)
	else:
		_failures += 1
		print("  FAIL - " + label)
