# Phase 1 manual checklist
Tick each item after running with F5. Note failures with reality id + F3 info.

## Startup
- [ ] Game opens with no red errors in Output (warnings are OK).
- [ ] F3 shows "Content validation: OK" and floor `floor_apartment_01`, reality `normal`.
- [ ] You start in the corridor facing away from the elevator; mouse is captured.

## Movement
- [ ] WASD, mouse look, Shift sprint (forward only), Ctrl/C crouch (you slow down, cannot stand under low ceilings), Space jump.
- [ ] No falling through floor, no sticking on walls/door frames.
- [ ] Esc pauses; sliders work; Resume recaptures the mouse; settings persist after restart.

## Interaction
- [ ] Looking at a door shows "[E] Open door 101"; E opens, E closes, creak/thud sounds play.
- [ ] Locked door shows message "It's locked." and rattle sound.
- [ ] Note on the table near the elevator: "[E] Read note" shows text; text differs per reality.
- [ ] F toggles flashlight with click; light lights the corridor.

## Elevator
- [ ] Panel prompt reads "Step inside the elevator" (no [E]) from outside; "[E] Press the button" inside.
- [ ] Pressing: doors close, black fade, rumble + shake, doors open, ding. Pressing during travel does nothing.
- [ ] Order of realities: Normal -> Distorted (green, longer) -> Impossible (red, tall, 12 doors) -> Normal.
- [ ] After each trip you are inside the cab and can walk out; no blocking errors.
- [ ] Rooms behind unlocked doors can be entered (open_room / huge_room); huge rooms have pillars.

## Debug panel (F3)
- [ ] Opens/closes, frees mouse, freezes player. Reality buttons switch + teleport to start.
- [ ] Teleport list contains elevator_cab, start, room_NN. Reset test run, Reload level and Test message work.

## Accessibility
- [ ] Reduced flashing: lights dim instead of strobing. Reduced camera shake: elevator shake barely visible. Prompt text size slider changes prompt size.
