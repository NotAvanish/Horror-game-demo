class_name PlayerSettings
extends Resource
## PlayerSettings: every tunable player number in ONE place.
## Edit res://resources/config/player_settings.tres in the Inspector (no code).
## Read by PlayerController (and it configures the InteractionSensor distance).

@export_group("Movement")
@export var walk_speed := 3.2
@export var sprint_multiplier := 1.7
@export var crouch_speed := 1.5
@export var acceleration := 12.0
@export_range(0.0, 1.0) var air_control := 0.3
@export var allow_jump := true
@export var jump_velocity := 3.8
@export var gravity := 14.0

@export_group("Body")
@export var body_radius := 0.35
@export var stand_height := 1.8
@export var crouch_height := 1.1
@export var eye_offset := 0.15
@export var crouch_transition_speed := 10.0
@export var crouch_is_toggle := false

@export_group("Camera")
@export var mouse_radians_per_pixel := 0.0022
@export var max_pitch_degrees := 85.0
@export var field_of_view := 75.0
@export var head_bob_amount := 0.03
@export var head_bob_frequency := 9.0

@export_group("Interaction")
@export var interaction_distance := 2.5
