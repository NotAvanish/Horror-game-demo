class_name Flashlight
extends SpotLight3D
## Flashlight: toggled with the "flashlight" action (F).
## Exported: brightness, light_range, cone_angle_degrees, cast_shadow, start_on,
##   use_battery (OFF by default), battery_seconds, flicker_when_low,
##   low_battery_fraction, toggle_sound (drop your own AudioStream here).
## Signals: toggled(is_on), battery_changed(fraction), battery_depleted
## Public API: toggle(), set_on(bool), trigger_failure(seconds), input_enabled.
## Dependencies: GameSettings.reduce_flashing, PlaceholderSounds.
## Shadows are off by default: they are expensive on integrated graphics.

signal toggled(is_on: bool)
signal battery_changed(fraction: float)
signal battery_depleted

@export_group("Light")
@export var brightness := 2.5
@export var light_range := 16.0
@export var cone_angle_degrees := 40.0
@export var cast_shadow := false
@export var start_on := false
@export_group("Battery (optional)")
@export var use_battery := false
@export var battery_seconds := 240.0
@export var flicker_when_low := true
@export_range(0.0, 1.0) var low_battery_fraction := 0.2
@export_group("Audio")
@export var toggle_sound: AudioStream

var input_enabled := true
var is_on := false
var battery_fraction := 1.0
var _failure_time := 0.0
var _audio: AudioStreamPlayer

func _ready() -> void:
	spot_range = light_range
	spot_angle = cone_angle_degrees
	shadow_enabled = cast_shadow
	light_energy = brightness
	_audio = AudioStreamPlayer.new()
	_audio.stream = toggle_sound if toggle_sound != null else PlaceholderSounds.get_sound("click")
	_audio.volume_db = -8.0
	add_child(_audio)
	set_on(start_on, false)

func _unhandled_input(event: InputEvent) -> void:
	if input_enabled and event.is_action_pressed("flashlight"):
		toggle()

func toggle() -> void:
	set_on(not is_on)

func set_on(value: bool, play_sound := true) -> void:
	if value and use_battery and battery_fraction <= 0.0:
		value = false   # dead battery: the click plays but the light stays off
	is_on = value
	visible = value
	if play_sound:
		_audio.play()
	toggled.emit(is_on)

## Makes the light flicker for a while (used later by scares / power failures).
func trigger_failure(seconds: float = 2.0) -> void:
	_failure_time = seconds

func _process(delta: float) -> void:
	if not is_on:
		return
	if use_battery:
		battery_fraction = maxf(battery_fraction - delta / battery_seconds, 0.0)
		battery_changed.emit(battery_fraction)
		if battery_fraction <= 0.0:
			set_on(false, false)
			battery_depleted.emit()
			return
	var flicker := _failure_time > 0.0 or (use_battery and flicker_when_low and battery_fraction < low_battery_fraction)
	_failure_time = maxf(_failure_time - delta, 0.0)
	if flicker and GameSettings.reduce_flashing:
		light_energy = brightness * 0.5          # steady dim instead of flashing
	elif flicker:
		light_energy = brightness * (0.0 if randf() < 0.25 else randf_range(0.5, 1.0))
	else:
		light_energy = brightness
