class_name PlayerController
extends CharacterBody3D
## PlayerController: first-person movement, mouse look, crouch, camera feel.
## ONLY movement/camera. Interaction lives in InteractionSensor, the light in
## Flashlight; elevator/doors/UI know nothing about this script's internals.
##
## Exported: settings (PlayerSettings resource - all tunable numbers live there).
## Public API: controls_enabled, teleport_to(Transform3D), set_camera_shake(strength),
##             sensor, flashlight, camera.
## Dependencies: GameSettings (autoload), InteractionSensor, Flashlight (child nodes in player.tscn).
## Extend: add new abilities as child-node components, do not grow this file.

@export var settings: PlayerSettings

## When false the player is frozen and ignores input (menus, debug panel, loading).
var controls_enabled := true:
	set(value):
		controls_enabled = value
		if not value:
			velocity = Vector3.ZERO
		if is_node_ready():
			sensor.sensing_enabled = value
			flashlight.input_enabled = value

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var collision: CollisionShape3D = $CollisionShape3D
@onready var sensor: InteractionSensor = $Head/Camera3D/InteractionSensor
@onready var flashlight: Flashlight = $Head/Camera3D/Flashlight

var _pitch := 0.0
var _height := 1.8
var _crouched := false
var _want_crouch := false
var _bob_time := 0.0
var _shake := 0.0
var _shape: CapsuleShape3D

func _ready() -> void:
	add_to_group("player")
	if settings == null:
		push_warning("PlayerController: no PlayerSettings assigned; using defaults.")
		settings = PlayerSettings.new()
	_shape = collision.shape as CapsuleShape3D
	_shape.radius = settings.body_radius
	_height = settings.stand_height
	_apply_height()
	camera.fov = settings.field_of_view
	sensor.target_position = Vector3(0.0, 0.0, -settings.interaction_distance)

func _unhandled_input(event: InputEvent) -> void:
	if not controls_enabled or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	var motion := event as InputEventMouseMotion
	if motion == null:
		return
	var sens := settings.mouse_radians_per_pixel * GameSettings.mouse_sensitivity
	rotate_y(-motion.relative.x * sens)
	var y_dir := -1.0 if GameSettings.invert_mouse_y else 1.0
	var limit := deg_to_rad(settings.max_pitch_degrees)
	_pitch = clampf(_pitch - motion.relative.y * sens * y_dir, -limit, limit)
	head.rotation.x = _pitch

func _physics_process(delta: float) -> void:
	if not controls_enabled:
		return
	_update_crouch(delta)

	if not is_on_floor():
		velocity.y -= settings.gravity * delta
	elif settings.allow_jump and not _crouched and Input.is_action_just_pressed("jump"):
		velocity.y = settings.jump_velocity

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := (global_transform.basis * Vector3(input_dir.x, 0.0, input_dir.y)).normalized()
	var speed := settings.walk_speed
	if _crouched:
		speed = settings.crouch_speed
	elif Input.is_action_pressed("sprint") and input_dir.y < 0.0:
		speed = settings.walk_speed * settings.sprint_multiplier
	var accel := settings.acceleration if is_on_floor() else settings.acceleration * settings.air_control
	velocity.x = move_toward(velocity.x, direction.x * speed, accel * delta)
	velocity.z = move_toward(velocity.z, direction.z * speed, accel * delta)
	move_and_slide()

	_update_camera_motion(delta, Vector2(velocity.x, velocity.z).length() > 0.5)

## Moves the player to a spawn transform (uses only the facing direction's yaw).
func teleport_to(xform: Transform3D) -> void:
	global_position = xform.origin
	var forward := -xform.basis.z
	rotation = Vector3(0.0, atan2(-forward.x, -forward.z), 0.0)
	_pitch = 0.0
	head.rotation.x = 0.0
	velocity = Vector3.ZERO

func set_camera_shake(strength: float) -> void:
	_shake = maxf(strength, 0.0)

func _update_crouch(delta: float) -> void:
	if settings.crouch_is_toggle:
		if Input.is_action_just_pressed("crouch"):
			_want_crouch = not _want_crouch
	else:
		_want_crouch = Input.is_action_pressed("crouch")
	if _want_crouch:
		_crouched = true
	elif _crouched and _has_headroom():
		_crouched = false
	var target := settings.crouch_height if _crouched else settings.stand_height
	if absf(_height - target) > 0.001:
		_height = lerpf(_height, target, clampf(settings.crouch_transition_speed * delta, 0.0, 1.0))
		_apply_height()

func _apply_height() -> void:
	_shape.height = _height
	collision.position.y = _height * 0.5
	head.position.y = _height - settings.eye_offset

func _has_headroom() -> bool:
	var space := get_world_3d().direct_space_state
	var from := global_position + Vector3.UP * settings.crouch_height
	var to := global_position + Vector3.UP * (settings.stand_height + 0.05)
	var query := PhysicsRayQueryParameters3D.create(from, to, 1, [get_rid()])
	return space.intersect_ray(query).is_empty()

func _update_camera_motion(delta: float, moving: bool) -> void:
	var motion_scale := 0.2 if GameSettings.reduced_camera_shake else 1.0
	var target := Vector3.ZERO
	if moving and is_on_floor():
		_bob_time += delta * settings.head_bob_frequency
		target.y = sin(_bob_time) * settings.head_bob_amount * motion_scale
		target.x = cos(_bob_time * 0.5) * settings.head_bob_amount * 0.5 * motion_scale
	camera.position = camera.position.lerp(target, clampf(10.0 * delta, 0.0, 1.0))
	if _shake > 0.0:
		camera.h_offset = randf_range(-1.0, 1.0) * _shake * motion_scale
		camera.v_offset = randf_range(-1.0, 1.0) * _shake * motion_scale
	elif camera.h_offset != 0.0 or camera.v_offset != 0.0:
		camera.h_offset = 0.0
		camera.v_offset = 0.0
