extends Node
## RealityManager (autoload)
## Responsibility: which reality is current, picking the next one, and sequencing a
## transition. It does NOT build geometry (GameWorld/FloorBuilder react to signals)
## and does NOT know about elevators (the Elevator just calls the API below).
##
## Transition protocol (used by Elevator):
##   begin_transition(id)   -> emits transition_started        (validates the id)
##   commit_transition()    -> switches current, emits reality_applied(definition)
##   finish_transition()    -> emits transition_finished
##   fail_transition(why)   -> rolls back to the previous reality, emits transition_failed
## Other entry points: choose_next_reality(), set_reality_immediate(id) (startup/debug),
##   load_floor(FloorDefinition), scripted_queue (append ids to force a scripted order).
## Selection: SEQUENCE (by sequence_order) or SEEDED_RANDOM (reproducible), from the
##   FloorDefinition. A scripted_queue entry always wins.
## Persistent state: story flags live in GameState and are never cleared here.
## Dependencies: ContentRegistry, GameState, FloorDefinition, RealityDefinition.

signal transition_started(from_id: String, to_id: String)
signal reality_applied(definition: RealityDefinition)
signal transition_finished(reality_id: String)
signal transition_failed(reason: String)

var current_reality_id := ""
var previous_reality_id := ""
var pending_reality_id := ""
var floor_definition: FloorDefinition
var scripted_queue: Array[String] = []

var _allowed: Array[String] = []
var _mode := FloorDefinition.SelectionMode.SEQUENCE
var _rng := RandomNumberGenerator.new()
var _committed := false

func load_floor(def: FloorDefinition) -> void:
	floor_definition = def
	_allowed.clear()
	for rid in def.allowed_reality_ids:
		if ContentRegistry.realities.has(rid):
			_allowed.append(rid)
		else:
			push_error("RealityManager: floor '%s' lists unknown reality '%s'" % [def.id, rid])
	_allowed.sort_custom(func(a: String, b: String) -> bool:
		return ContentRegistry.realities[a].sequence_order < ContentRegistry.realities[b].sequence_order)
	_mode = def.selection_mode
	if def.random_seed == 0:
		_rng.randomize()
	else:
		_rng.seed = def.random_seed
	scripted_queue.clear()
	pending_reality_id = ""
	current_reality_id = ""
	previous_reality_id = ""
	set_reality_immediate(def.starting_reality_id)

## Switches instantly with no elevator (startup, debug panel).
func set_reality_immediate(id: String) -> bool:
	if ContentRegistry.get_reality(id) == null:
		return false
	var old_id := current_reality_id
	transition_started.emit(old_id, id)
	previous_reality_id = old_id
	current_reality_id = id
	pending_reality_id = ""
	_committed = false
	_apply(id)
	transition_finished.emit(id)
	return true

func choose_next_reality() -> String:
	while not scripted_queue.is_empty():
		var queued: String = scripted_queue.pop_front()
		if ContentRegistry.get_reality(queued) != null:
			return queued
	var candidates: Array[String] = []
	for rid in _allowed:
		if rid != current_reality_id:
			candidates.append(rid)
	if candidates.is_empty():
		return ""
	if _mode == FloorDefinition.SelectionMode.SEEDED_RANDOM:
		return candidates[_rng.randi_range(0, candidates.size() - 1)]
	var idx := _allowed.find(current_reality_id)
	return _allowed[(idx + 1) % _allowed.size()]

func can_begin_transition() -> bool:
	return pending_reality_id == ""

func begin_transition(destination_id: String) -> bool:
	if pending_reality_id != "":
		push_warning("RealityManager: a transition is already pending ('%s')" % pending_reality_id)
		return false
	if ContentRegistry.get_reality(destination_id) == null:
		return false
	pending_reality_id = destination_id
	_committed = false
	transition_started.emit(current_reality_id, destination_id)
	return true

func commit_transition() -> bool:
	if pending_reality_id == "":
		push_warning("RealityManager: commit_transition() with nothing pending")
		return false
	previous_reality_id = current_reality_id
	current_reality_id = pending_reality_id
	pending_reality_id = ""
	_committed = true
	_apply(current_reality_id)
	return true

func finish_transition() -> void:
	_committed = false
	transition_finished.emit(current_reality_id)

func fail_transition(reason: String) -> void:
	push_error("RealityManager: transition failed: " + reason)
	if _committed and previous_reality_id != "":
		current_reality_id = previous_reality_id
		_apply(current_reality_id)
	pending_reality_id = ""
	_committed = false
	transition_failed.emit(reason)

func _apply(id: String) -> void:
	var def := ContentRegistry.get_reality(id)
	if def == null:
		return
	if not GameState.has_flag("visited_" + id):
		GameState.set_flag("visited_" + id)
		for flag in def.flags_on_enter:
			GameState.set_flag(flag)
	reality_applied.emit(def)
