class_name RealityDefinition
extends Resource
## RealityDefinition: ONE reality (Normal, Distorted, Impossible, ...) as pure data.
## To add a reality: duplicate a .tres in res://resources/realities/, change the
## values in the Inspector, give it a NEW unique `id`. No code changes needed.
## The FloorBuilder, RealityAtmosphere and RealityManager read these fields.
## Add the id to a FloorDefinition's allowed_reality_ids to make the elevator visit it.
## validate() is run by ContentRegistry; invalid definitions are rejected with a message.

const VALID_DOOR_MODES := ["open_room", "huge_room", "locked"]

@export var id := ""
@export var display_name := ""
@export_multiline var description := ""
## Order used by the elevator in SEQUENCE mode (lowest first).
@export var sequence_order := 0

@export_group("Layout")
@export var corridor_length := 30.0
@export var corridor_width := 3.0
@export var ceiling_height := 3.0
## One entry per door. Doors alternate left/right starting on the left.
@export var apartment_numbers := PackedStringArray()
## Same length as apartment_numbers. Values: open_room, huge_room, locked.
@export var door_modes := PackedStringArray()
@export var first_door_offset := 4.0
@export var door_spacing := 4.5
@export var apartment_room_depth := 4.5
@export var apartment_room_width := 4.5

@export_group("Colours (placeholder materials)")
@export var wall_color := Color(0.5, 0.5, 0.5)
@export var floor_color := Color(0.2, 0.2, 0.2)
@export var ceiling_color := Color(0.4, 0.4, 0.4)
@export var door_color := Color(0.25, 0.15, 0.1)

@export_group("Corridor lights")
@export var light_color := Color(1.0, 0.85, 0.6)
@export var light_energy := 1.2
@export var light_range := 6.5
@export var light_spacing := 6.0
## Hard cap on lights (low-end hardware).
@export var max_corridor_lights := 8
## Chance per second that a light starts a flicker burst. 0 = steady.
@export_range(0.0, 1.0) var flicker_chance := 0.0

@export_group("Atmosphere")
@export var fog_enabled := true
@export var fog_density := 0.02
@export var fog_color := Color(0.2, 0.2, 0.22)
@export var ambient_color := Color(0.1, 0.1, 0.12)
@export var ambient_energy := 0.6

@export_group("Props and story")
@export var clutter_count := 4
@export var clutter_seed := 1
@export_multiline var note_text := ""
## Flags set in GameState the first time this reality is applied.
@export var flags_on_enter := PackedStringArray()

func validate() -> PackedStringArray:
	var errs := PackedStringArray()
	var tag := "RealityDefinition '%s': " % id
	if id.strip_edges() == "":
		errs.append("A RealityDefinition has an empty id (display_name='%s')" % display_name)
		return errs
	if corridor_length < 8.0:
		errs.append(tag + "corridor_length must be >= 8")
	if corridor_width < 2.6:
		errs.append(tag + "corridor_width must be >= 2.6")
	if ceiling_height < 2.6:
		errs.append(tag + "ceiling_height must be >= 2.6")
	if light_spacing <= 0.0 or max_corridor_lights < 1:
		errs.append(tag + "light_spacing must be > 0 and max_corridor_lights >= 1")
	if apartment_numbers.size() != door_modes.size():
		errs.append(tag + "apartment_numbers (%d) and door_modes (%d) must have the same length" % [apartment_numbers.size(), door_modes.size()])
	for mode in door_modes:
		if not VALID_DOOR_MODES.has(mode):
			errs.append(tag + "unknown door mode '%s' (valid: %s)" % [mode, VALID_DOOR_MODES])
	if apartment_numbers.size() > 0:
		var needed := first_door_offset + (apartment_numbers.size() - 1) * door_spacing + 1.5
		if needed > corridor_length:
			errs.append(tag + "doors need %.1f m of corridor but corridor_length is %.1f" % [needed, corridor_length])
	return errs
