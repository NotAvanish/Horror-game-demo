class_name GeometryUtil
extends RefCounted
## GeometryUtil: tiny helpers for placeholder (procedural) geometry. Materials and
## box meshes/shapes are cached and reused (cheap on low-end GPUs).
## To replace placeholders with real models, see docs/ADD_AUDIO_AND_MATERIALS.md.

static var _materials := {}
static var _meshes := {}
static var _shapes := {}

static func material(color: Color, emissive := false) -> StandardMaterial3D:
	var key := "%s_%s" % [color.to_html(true), emissive]
	if _materials.has(key):
		return _materials[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.95
	if emissive:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = 1.5
	_materials[key] = m
	return m

static func add_visual_box(parent: Node, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var key := str(size)
	var mesh: BoxMesh
	if _meshes.has(key):
		mesh = _meshes[key]
	else:
		mesh = BoxMesh.new()
		mesh.size = size
		_meshes[key] = mesh
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi

static func add_collision_box(body: CollisionObject3D, size: Vector3, pos: Vector3) -> CollisionShape3D:
	var key := str(size)
	var shape: BoxShape3D
	if _shapes.has(key):
		shape = _shapes[key]
	else:
		shape = BoxShape3D.new()
		shape.size = size
		_shapes[key] = shape
	var cs := CollisionShape3D.new()
	cs.shape = shape
	cs.position = pos
	body.add_child(cs)
	return cs

## A solid static box (visual + collision) centred at `pos`. Layer 1 (world).
static func add_solid_box(parent: Node, size: Vector3, pos: Vector3, mat: Material) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	add_visual_box(body, size, Vector3.ZERO, mat)
	add_collision_box(body, size, Vector3.ZERO)
	parent.add_child(body)
	return body
