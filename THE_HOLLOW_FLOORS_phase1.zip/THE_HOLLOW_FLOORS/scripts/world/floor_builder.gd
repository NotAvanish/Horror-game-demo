class_name FloorBuilder
extends Node3D
## FloorBuilder: turns a RealityDefinition into the corridor, doors, rooms, lights,
## clutter and note (procedural placeholder geometry). Rebuilt on every reality change
## while the elevator is closed and the screen is black.
## Public API: build(definition), spawn_points (Dictionary id -> Marker3D).
## Signal: built(reality_id)
## Layout: the elevator front is at z = 1.45; the corridor runs along +Z from there.
##   Doors alternate left (-X, even index) and right (+X, odd index).
## Spawns registered: start, corridor_mid, corridor_end, room_NN (one per room).
## To replace this with hand-made scenes later, keep the same spawn ids.
## Dependencies: RealityDefinition, Door, FlickerLight, ReadableNote, GeometryUtil.

signal built(reality_id: String)

const WALL_T := 0.2
const DOOR_W := 1.0
const DOOR_H := 2.2
const START_Z := 1.45
const TILE_LEN := 6.0

var spawn_points: Dictionary = {}

var _root: Node3D
var _def: RealityDefinition

func build(def: RealityDefinition) -> void:
	_def = def
	_clear()
	_build_shell()
	_build_doors_and_rooms()
	_build_lights()
	_build_clutter()
	_build_note()
	var z_end := START_Z + def.corridor_length
	_add_spawn("start", Vector3(0.0, 0.05, START_Z + 2.0), PI)
	_add_spawn("corridor_mid", Vector3(0.0, 0.05, START_Z + def.corridor_length * 0.5), PI)
	_add_spawn("corridor_end", Vector3(0.0, 0.05, z_end - 1.5), 0.0)
	built.emit(def.id)

func _clear() -> void:
	spawn_points.clear()
	if _root != null:
		remove_child(_root)   # leaves the physics space immediately
		_root.queue_free()
	_root = Node3D.new()
	_root.name = "FloorContent"
	add_child(_root)

func _add_spawn(id: String, pos: Vector3, yaw: float) -> void:
	var marker := Marker3D.new()
	marker.name = id
	marker.position = pos
	marker.rotation = Vector3(0.0, yaw, 0.0)
	_root.add_child(marker)
	spawn_points[id] = marker

func _door_z(index: int) -> float:
	return START_Z + _def.first_door_offset + index * _def.door_spacing

func _door_side(index: int) -> float:
	return -1.0 if index % 2 == 0 else 1.0

# ---------------------------------------------------------------- shell

func _build_shell() -> void:
	var w := _def.corridor_width
	var h := _def.ceiling_height
	var z_end := START_Z + _def.corridor_length
	var floor_mat := GeometryUtil.material(_def.floor_color)
	var ceil_mat := GeometryUtil.material(_def.ceiling_color)
	var wall_mat := GeometryUtil.material(_def.wall_color)
	# Floor/ceiling in short tiles so each tile is only lit by nearby lights.
	var z := START_Z
	while z < z_end - 0.01:
		var seg := minf(TILE_LEN, z_end - z)
		var zc := z + seg * 0.5
		GeometryUtil.add_solid_box(_root, Vector3(w, 0.2, seg), Vector3(0.0, -0.1, zc), floor_mat)
		GeometryUtil.add_solid_box(_root, Vector3(w, 0.2, seg), Vector3(0.0, h + 0.1, zc), ceil_mat)
		z += seg
	GeometryUtil.add_solid_box(_root, Vector3(w + 2.0 * WALL_T, h, WALL_T), Vector3(0.0, h * 0.5, z_end + WALL_T * 0.5), wall_mat)
	_build_side_wall(-1.0)
	_build_side_wall(1.0)

func _build_side_wall(side: float) -> void:
	var w := _def.corridor_width
	var h := _def.ceiling_height
	var mat := GeometryUtil.material(_def.wall_color)
	var x := side * (w * 0.5 + WALL_T * 0.5)
	var cursor := START_Z
	for i in _def.apartment_numbers.size():
		if _door_side(i) != side:
			continue
		var zc := _door_z(i)
		_wall_segment(x, cursor, zc - DOOR_W * 0.5, h, mat)
		var lintel_h := h - DOOR_H
		GeometryUtil.add_solid_box(_root, Vector3(WALL_T, lintel_h, DOOR_W), Vector3(x, DOOR_H + lintel_h * 0.5, zc), mat)
		cursor = zc + DOOR_W * 0.5
	_wall_segment(x, cursor, START_Z + _def.corridor_length, h, mat)

func _wall_segment(x: float, z_from: float, z_to: float, h: float, mat: Material) -> void:
	var seg := z_to - z_from
	if seg < 0.01:
		return
	GeometryUtil.add_solid_box(_root, Vector3(WALL_T, h, seg), Vector3(x, h * 0.5, z_from + seg * 0.5), mat)

# ---------------------------------------------------------------- doors + rooms

func _build_doors_and_rooms() -> void:
	var w := _def.corridor_width
	var h := _def.ceiling_height
	for i in _def.apartment_numbers.size():
		var number := _def.apartment_numbers[i]
		var mode := _def.door_modes[i] if i < _def.door_modes.size() else "open_room"
		var side := _door_side(i)
		var zc := _door_z(i)

		var door := Door.new()
		door.name = "Door_%d" % i
		door.door_label = number
		door.locked = (mode == "locked")
		door.open_angle_degrees = 90.0 * side     # swings into the room
		door.door_color = _def.door_color
		door.position = Vector3(side * (w * 0.5 + WALL_T * 0.5), 0.0, zc - DOOR_W * 0.5)
		_root.add_child(door)

		var plate := Label3D.new()
		plate.text = number
		plate.font_size = 64
		plate.pixel_size = 0.004
		plate.modulate = Color(0.9, 0.85, 0.7)
		plate.position = Vector3(side * (w * 0.5 - 0.02), 2.55, zc)
		plate.rotation_degrees.y = -90.0 * side
		_root.add_child(plate)

		if mode == "open_room":
			_build_room(i, side, zc, _def.apartment_room_depth, _def.apartment_room_width, h, false)
		elif mode == "huge_room":
			_build_room(i, side, zc, 9.0, 8.0, h * 1.8, true)

func _build_room(index: int, side: float, zc: float, depth: float, width: float, rh: float, pillars: bool) -> void:
	var w := _def.corridor_width
	var h := _def.ceiling_height
	var wall_mat := GeometryUtil.material(_def.wall_color.darkened(0.15))
	var floor_mat := GeometryUtil.material(_def.floor_color)
	var ceil_mat := GeometryUtil.material(_def.ceiling_color)
	var x0 := side * (w * 0.5 + WALL_T)   # where the room interior starts
	# floor starts at the corridor edge so there is no gap under the doorway
	GeometryUtil.add_solid_box(_root, Vector3(depth + WALL_T, 0.2, width + 2.0 * WALL_T), Vector3(side * (w * 0.5 + (depth + WALL_T) * 0.5), -0.1, zc), floor_mat)
	GeometryUtil.add_solid_box(_root, Vector3(depth + WALL_T, 0.2, width + 2.0 * WALL_T), Vector3(x0 + side * (depth + WALL_T) * 0.5, rh + 0.1, zc), ceil_mat)
	# back wall and the two side walls
	GeometryUtil.add_solid_box(_root, Vector3(WALL_T, rh, width + 2.0 * WALL_T), Vector3(x0 + side * (depth + WALL_T * 0.5), rh * 0.5, zc), wall_mat)
	for zs in [-1.0, 1.0]:
		GeometryUtil.add_solid_box(_root, Vector3(depth + WALL_T, rh, WALL_T), Vector3(x0 + side * (depth + WALL_T) * 0.5, rh * 0.5, zc + zs * (width * 0.5 + WALL_T * 0.5)), wall_mat)
	if rh > h:   # taller room: close the strip above the corridor wall
		GeometryUtil.add_solid_box(_root, Vector3(WALL_T, rh - h, width + 2.0 * WALL_T), Vector3(side * (w * 0.5 + WALL_T * 0.5), h + (rh - h) * 0.5, zc), wall_mat)
	# a table near the back wall
	var prop_mat := GeometryUtil.material(_def.door_color.lightened(0.1))
	GeometryUtil.add_solid_box(_root, Vector3(0.9, 0.75, 0.6), Vector3(x0 + side * (depth - 0.8), 0.375, zc + width * 0.25), prop_mat)
	if pillars:
		for zs in [-2.0, 2.0]:
			GeometryUtil.add_solid_box(_root, Vector3(0.5, rh, 0.5), Vector3(x0 + side * depth * 0.5, rh * 0.5, zc + zs), wall_mat)
	_add_spawn("room_%02d" % index, Vector3(x0 + side * depth * 0.5, 0.05, zc), -side * PI * 0.5)

# ---------------------------------------------------------------- lights, clutter, note

func _build_lights() -> void:
	var h := _def.ceiling_height
	var count := clampi(int(_def.corridor_length / _def.light_spacing), 1, _def.max_corridor_lights)
	var spacing := _def.corridor_length / count
	var fixture_mat := GeometryUtil.material(_def.light_color, true)
	for k in count:
		var z := START_Z + spacing * (k + 0.5)
		var light := FlickerLight.new()
		light.base_energy = _def.light_energy
		light.flicker_chance = _def.flicker_chance
		light.light_color = _def.light_color
		light.omni_range = _def.light_range
		light.shadow_enabled = false
		light.position = Vector3(0.0, h - 0.25, z)
		_root.add_child(light)
		GeometryUtil.add_visual_box(_root, Vector3(0.6, 0.06, 0.2), Vector3(0.0, h - 0.03, z), fixture_mat)

func _build_clutter() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = _def.clutter_seed
	var w := _def.corridor_width
	var mat := GeometryUtil.material(_def.floor_color.darkened(0.3))
	for i in _def.clutter_count:
		var z := rng.randf_range(START_Z + 2.5, START_Z + _def.corridor_length - 1.0)
		var side := -1.0 if rng.randf() < 0.5 else 1.0
		var box := Vector3(rng.randf_range(0.3, 0.7), rng.randf_range(0.2, 0.8), rng.randf_range(0.3, 0.8))
		var yaw := rng.randf_range(-0.4, 0.4)
		# keep a clear walking lane down the middle (spawns are validated against it)
		var min_off := 0.65 + box.x * 0.5
		var max_off := w * 0.5 - box.x * 0.5 - 0.05
		if max_off < min_off or _near_door(z):
			continue
		var off := clampf(max_off - rng.randf_range(0.0, 0.2), min_off, max_off)
		var body := GeometryUtil.add_solid_box(_root, box, Vector3(side * off, box.y * 0.5, z), mat)
		body.rotation.y = yaw

func _near_door(z: float) -> bool:
	for i in _def.apartment_numbers.size():
		if absf(z - _door_z(i)) < 1.3:
			return true
	return false

func _build_note() -> void:
	if _def.note_text == "":
		return
	var tx := -(_def.corridor_width * 0.5 - 0.4)
	var tz := START_Z + 1.2
	GeometryUtil.add_solid_box(_root, Vector3(0.6, 0.7, 0.8), Vector3(tx, 0.35, tz), GeometryUtil.material(_def.door_color))
	var note := ReadableNote.new()
	note.note_text = _def.note_text
	note.position = Vector3(tx, 0.73, tz)
	_root.add_child(note)
