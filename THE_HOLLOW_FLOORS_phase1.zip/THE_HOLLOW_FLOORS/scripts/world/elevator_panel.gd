class_name ElevatorPanel
extends Interactable
## ElevatorPanel: the button inside the cab. It knows NOTHING about the Elevator:
## the Elevator assigns `gate` (Callable -> bool) and `text_provider` (Callable -> String)
## and listens to the inherited `interacted` signal. This keeps the two decoupled.

var gate: Callable
var text_provider: Callable

func _ready() -> void:
	GeometryUtil.add_visual_box(self, Vector3(0.06, 0.4, 0.25), Vector3.ZERO, GeometryUtil.material(Color(0.2, 0.2, 0.22)))
	GeometryUtil.add_visual_box(self, Vector3(0.04, 0.08, 0.08), Vector3(-0.04, 0.05, 0.0), GeometryUtil.material(Color(1.0, 0.6, 0.1), true))
	GeometryUtil.add_collision_box(self, Vector3(0.2, 0.5, 0.4), Vector3.ZERO)

func can_interact(_actor: Node) -> bool:
	return enabled and (gate.is_null() or gate.call())

func get_interaction_text() -> String:
	if text_provider.is_null():
		return prompt_text
	return text_provider.call()
