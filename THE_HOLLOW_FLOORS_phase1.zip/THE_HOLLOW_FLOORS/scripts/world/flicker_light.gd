class_name FlickerLight
extends OmniLight3D
## FlickerLight: an omni light that randomly flickers in short bursts.
## Exported: base_energy, flicker_chance (per second), burst_duration.
## Respects the "reduce flashing" accessibility setting (dims steadily instead).

@export var base_energy := 1.0
@export_range(0.0, 1.0) var flicker_chance := 0.0
@export var burst_duration := 0.4

var _burst := 0.0

func _ready() -> void:
	light_energy = base_energy
	set_process(flicker_chance > 0.0)

func _process(delta: float) -> void:
	if _burst > 0.0:
		_burst -= delta
		if GameSettings.reduce_flashing:
			light_energy = base_energy * 0.6
		else:
			light_energy = base_energy * (0.0 if randf() < 0.3 else randf_range(0.3, 1.0))
		if _burst <= 0.0:
			light_energy = base_energy
	elif randf() < flicker_chance * delta:
		_burst = burst_duration * randf_range(0.5, 1.5)
