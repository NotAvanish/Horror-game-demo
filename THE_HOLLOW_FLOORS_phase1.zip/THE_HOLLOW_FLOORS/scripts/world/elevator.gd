class_name Elevator
extends Node3D
## Elevator: builds the cab, and runs trips with an explicit STATE MACHINE:
##   OPEN -> CLOSING -> TRAVELLING -> OPENING -> OPEN        (normal trip)
##   CLOSING/TRAVELLING -> FAILED -> OPENING -> OPEN          (failure recovery)
## Every state change goes through _set_state(), which rejects illegal transitions.
## Duplicate requests are impossible: request_travel() only works in OPEN.
##
## Exported (editable on the Elevator node): door_time, travel_duration, fade_time,
##   shake_strength, cab_light_color/energy, ding_sound, close_sound, rumble_sound.
## Signals: state_changed, travel_started(dest_id), travel_finished(reality_id), travel_failed(reason)
## Public API: request_travel(dest_id := ""), can_accept_request(), is_player_inside().
## Injected by Main/GameWorld (no node paths): fader, player, validate_callback.
## Dependencies: RealityManager, GeometryUtil, ElevatorPanel, ScreenFader, PlayerController.
## The cab is permanent; only the corridor is rebuilt while the doors are closed and
## the screen is black, so the player never sees the swap.

enum State { OPEN, CLOSING, TRAVELLING, OPENING, FAILED }

const ALLOWED_TRANSITIONS := {
	State.OPEN: [State.CLOSING],
	State.CLOSING: [State.TRAVELLING, State.FAILED],
	State.TRAVELLING: [State.OPENING, State.FAILED],
	State.OPENING: [State.OPEN],
	State.FAILED: [State.OPENING],
}

const CAB_HEIGHT := 2.6
const DOOR_HEIGHT := 2.2
const LEAF_CLOSED_X := 0.35
const LEAF_OPEN_X := 0.9

signal state_changed(new_state: State, old_state: State)
signal travel_started(destination_id: String)
signal travel_finished(reality_id: String)
signal travel_failed(reason: String)

@export var door_time := 1.2
@export var travel_duration := 3.5
@export var fade_time := 0.7
@export var shake_strength := 0.02
@export var cab_light_color := Color(1.0, 0.9, 0.7)
@export var cab_light_energy := 1.0
@export var ding_sound: AudioStream
@export var close_sound: AudioStream
@export var rumble_sound: AudioStream

var state := State.OPEN
var fader: ScreenFader
var player: PlayerController
## Returns true when every required spawn is valid. Set by GameWorld.
var validate_callback: Callable
var spawn_marker: Marker3D

var _leaf_left: StaticBody3D
var _leaf_right: StaticBody3D
var _ding: AudioStreamPlayer3D
var _thud: AudioStreamPlayer3D
var _rumble: AudioStreamPlayer

func _ready() -> void:
	_build_cab()
	_build_door_leaves()
	_build_panel()
	_build_audio()
	spawn_marker = Marker3D.new()
	spawn_marker.name = "ElevatorCabSpawn"
	spawn_marker.position = Vector3(0.0, 0.05, -0.2)
	spawn_marker.rotation = Vector3(0.0, PI, 0.0)   # faces +Z, out of the doors
	add_child(spawn_marker)

# ---------------------------------------------------------------- public API

func is_player_inside() -> bool:
	if player == null:
		return false
	var p := to_local(player.global_position)
	return absf(p.x) < 1.25 and p.z > -1.25 and p.z < 1.25 and p.y > -0.5 and p.y < CAB_HEIGHT

func can_accept_request() -> bool:
	return state == State.OPEN and is_player_inside() and RealityManager.can_begin_transition()

## Starts a trip. `destination_id` empty = ask RealityManager. Returns false if rejected.
func request_travel(destination_id: String = "") -> bool:
	if state != State.OPEN:
		push_warning("Elevator: travel requested while %s" % State.keys()[state])
		return false
	if not RealityManager.can_begin_transition():
		return false
	var dest := destination_id if destination_id != "" else RealityManager.choose_next_reality()
	if dest == "" or not RealityManager.begin_transition(dest):
		EventBus.show_message("The buttons are dead.", 2.5)
		return false
	_set_state(State.CLOSING)
	travel_started.emit(dest)
	_run_travel(dest)
	return true

# ---------------------------------------------------------------- state machine

func _set_state(new_state: State) -> bool:
	if not ALLOWED_TRANSITIONS[state].has(new_state):
		push_error("Elevator: illegal transition %s -> %s" % [State.keys()[state], State.keys()[new_state]])
		return false
	var old := state
	state = new_state
	state_changed.emit(new_state, old)
	return true

func _run_travel(dest: String) -> void:
	await _animate_doors(false)
	_thud.play()
	_set_state(State.TRAVELLING)
	_rumble.play()
	if fader != null:
		await fader.fade_to(1.0, fade_time)
	if player != null:
		player.set_camera_shake(shake_strength)
	await get_tree().create_timer(travel_duration * 0.5, false).timeout

	# World changes while the screen is black and the doors are shut.
	RealityManager.commit_transition()
	# New physics bodies only exist for queries after a physics step.
	await get_tree().physics_frame
	await get_tree().physics_frame
	var ok := _validate_exit()
	if not ok:
		_set_state(State.FAILED)
		RealityManager.fail_transition("required spawn points invalid for reality '%s'" % dest)
		await get_tree().physics_frame
		await get_tree().physics_frame
		EventBus.show_message("The elevator shudders and goes back.", 3.0)
		travel_failed.emit("invalid spawn for " + dest)

	await get_tree().create_timer(travel_duration * 0.5, false).timeout
	_rumble.stop()
	if player != null:
		player.set_camera_shake(0.0)
		if not is_player_inside():
			player.teleport_to(spawn_marker.global_transform)   # safety net
	_set_state(State.OPENING)
	if fader != null:
		fader.fade_to(0.0, fade_time)   # not awaited: fade while doors open
	await _animate_doors(true)
	_ding.play()
	_set_state(State.OPEN)
	if ok:
		GameState.elevator_rides += 1
		RealityManager.finish_transition()
		travel_finished.emit(RealityManager.current_reality_id)

func _validate_exit() -> bool:
	if validate_callback.is_null():
		return true
	return validate_callback.call()

func _animate_doors(open: bool) -> void:
	var x := LEAF_OPEN_X if open else LEAF_CLOSED_X
	var tween := create_tween()
	tween.set_parallel(true)
	tween.set_trans(Tween.TRANS_SINE)
	tween.tween_property(_leaf_left, "position:x", -x, door_time)
	tween.tween_property(_leaf_right, "position:x", x, door_time)
	await tween.finished

# ---------------------------------------------------------------- construction

func _build_cab() -> void:
	var wall := GeometryUtil.material(Color(0.32, 0.32, 0.34))
	var floor_mat := GeometryUtil.material(Color(0.18, 0.18, 0.2))
	GeometryUtil.add_solid_box(self, Vector3(3.0, 0.2, 2.8), Vector3(0.0, -0.1, 0.05), floor_mat)
	GeometryUtil.add_solid_box(self, Vector3(3.0, 0.2, 2.8), Vector3(0.0, CAB_HEIGHT + 0.1, 0.05), wall)
	GeometryUtil.add_solid_box(self, Vector3(3.0, CAB_HEIGHT, 0.2), Vector3(0.0, CAB_HEIGHT * 0.5, -1.35), wall)
	for side in [-1.0, 1.0]:
		GeometryUtil.add_solid_box(self, Vector3(0.2, CAB_HEIGHT, 2.8), Vector3(side * 1.35, CAB_HEIGHT * 0.5, 0.05), wall)
		GeometryUtil.add_solid_box(self, Vector3(0.8, CAB_HEIGHT, 0.2), Vector3(side * 1.1, CAB_HEIGHT * 0.5, 1.35), wall)
	var lintel_h := CAB_HEIGHT - DOOR_HEIGHT
	GeometryUtil.add_solid_box(self, Vector3(1.4, lintel_h, 0.2), Vector3(0.0, DOOR_HEIGHT + lintel_h * 0.5, 1.35), wall)
	var light := OmniLight3D.new()
	light.position = Vector3(0.0, CAB_HEIGHT - 0.3, 0.0)
	light.omni_range = 5.0
	light.light_energy = cab_light_energy
	light.light_color = cab_light_color
	add_child(light)
	GeometryUtil.add_visual_box(self, Vector3(0.7, 0.06, 0.3), Vector3(0.0, CAB_HEIGHT - 0.03, 0.0), GeometryUtil.material(cab_light_color, true))

func _build_door_leaves() -> void:
	var mat := GeometryUtil.material(Color(0.45, 0.45, 0.48))
	_leaf_left = GeometryUtil.add_solid_box(self, Vector3(0.7, DOOR_HEIGHT, 0.08), Vector3(0.0, DOOR_HEIGHT * 0.5, 1.2), mat)
	_leaf_right = GeometryUtil.add_solid_box(self, Vector3(0.7, DOOR_HEIGHT, 0.08), Vector3(0.0, DOOR_HEIGHT * 0.5, 1.2), mat)
	_leaf_left.position.x = -LEAF_OPEN_X    # start open
	_leaf_right.position.x = LEAF_OPEN_X

func _build_panel() -> void:
	var panel := ElevatorPanel.new()
	panel.position = Vector3(1.22, 1.2, -0.4)
	panel.prompt_text = "Press the button"
	panel.gate = Callable(self, "can_accept_request")
	panel.text_provider = Callable(self, "_panel_text")
	panel.interacted.connect(_on_panel_interacted)
	add_child(panel)

func _panel_text() -> String:
	if state != State.OPEN:
		return "The elevator is moving"
	if not is_player_inside():
		return "Step inside the elevator"
	return "Press the button"

func _on_panel_interacted(_actor: Node) -> void:
	request_travel()

func _build_audio() -> void:
	_ding = AudioStreamPlayer3D.new()
	_ding.stream = ding_sound if ding_sound != null else PlaceholderSounds.get_sound("ding")
	_ding.position = Vector3(0.0, 2.0, 0.0)
	add_child(_ding)
	_thud = AudioStreamPlayer3D.new()
	_thud.stream = close_sound if close_sound != null else PlaceholderSounds.get_sound("thud")
	_thud.position = Vector3(0.0, 1.0, 1.2)
	add_child(_thud)
	_rumble = AudioStreamPlayer.new()
	_rumble.stream = rumble_sound if rumble_sound != null else PlaceholderSounds.get_sound("rumble")
	_rumble.volume_db = -14.0
	add_child(_rumble)
