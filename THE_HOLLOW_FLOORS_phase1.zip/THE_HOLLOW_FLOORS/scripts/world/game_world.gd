class_name GameWorld
extends Node3D
## GameWorld: glues the world pieces together. On every reality change it updates the
## atmosphere and rebuilds the floor. Also answers spawn questions for other systems.
## Exported (assigned in main.tscn): floor_builder, elevator, atmosphere.
## Signals: spawns_changed
## Public API: get_spawn(id), get_spawn_ids(), validate_spawn(id), validate_required_spawns().
## Dependencies: RealityManager (signal), FloorBuilder, Elevator, RealityAtmosphere.

signal spawns_changed

@export var floor_builder: FloorBuilder
@export var elevator: Elevator
@export var atmosphere: RealityAtmosphere

func _ready() -> void:
	if floor_builder == null or elevator == null or atmosphere == null:
		push_error("GameWorld: floor_builder / elevator / atmosphere must be assigned in the Inspector.")
		return
	elevator.validate_callback = Callable(self, "validate_required_spawns")
	RealityManager.reality_applied.connect(_on_reality_applied)

func _on_reality_applied(def: RealityDefinition) -> void:
	atmosphere.apply(def)
	floor_builder.build(def)
	spawns_changed.emit()

func get_spawn(id: String) -> Marker3D:
	if id == "elevator_cab":
		return elevator.spawn_marker
	return floor_builder.spawn_points.get(id)

func get_spawn_ids() -> PackedStringArray:
	var ids := PackedStringArray(["elevator_cab"])
	for id in floor_builder.spawn_points.keys():
		ids.append(id)
	return ids

## True if the spawn exists, has floor below it, and the player capsule fits there.
## Needs the physics server to be up to date (wait two physics frames after a rebuild).
func validate_spawn(id: String) -> bool:
	var marker := get_spawn(id)
	if marker == null or not is_instance_valid(marker) or not marker.is_inside_tree():
		push_error("GameWorld: spawn '%s' does not exist" % id)
		return false
	var space := get_world_3d().direct_space_state
	var ray := PhysicsRayQueryParameters3D.create(marker.global_position + Vector3.UP * 0.5, marker.global_position + Vector3.DOWN * 0.6, 1)
	if space.intersect_ray(ray).is_empty():
		push_error("GameWorld: spawn '%s' has no floor below it" % id)
		return false
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.33
	capsule.height = 1.7
	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = capsule
	query.transform = Transform3D(Basis.IDENTITY, marker.global_position + Vector3.UP * 0.95)
	query.collision_mask = 1
	if not space.intersect_shape(query, 1).is_empty():
		push_error("GameWorld: spawn '%s' is blocked by geometry" % id)
		return false
	return true

func validate_required_spawns() -> bool:
	var required := PackedStringArray(["start", "elevator_cab"])
	if RealityManager.floor_definition != null:
		required = RealityManager.floor_definition.required_spawn_ids
	var ok := true
	for id in required:
		if not validate_spawn(id):
			ok = false
	return ok
