class_name FloorDefinition
extends Resource
## FloorDefinition: which realities a floor can show, where it starts, which spawns
## must be valid after every elevator trip, and how the elevator picks realities.
## Phase 1 builds geometry procedurally from the RealityDefinition, so `scene_path`
## is reserved for Phase 4 (hand-made floor scenes) and is not used yet.
## To add a floor definition: duplicate resources/floors/floor_apartment_01.tres.

enum SelectionMode { SEQUENCE, SEEDED_RANDOM }

@export var id := ""
@export var display_name := ""
@export_multiline var description := ""
@export var scene_path := ""
@export var starting_reality_id := "normal"
@export var allowed_reality_ids := PackedStringArray()
## Spawn ids that must exist and be unobstructed after every transition.
@export var required_spawn_ids := PackedStringArray(["start", "elevator_cab"])
@export var selection_mode := SelectionMode.SEQUENCE
## 0 = random seed each run. Any other number = reproducible sequence.
@export var random_seed := 1337

func validate() -> PackedStringArray:
	var errs := PackedStringArray()
	if id.strip_edges() == "":
		errs.append("A FloorDefinition has an empty id (display_name='%s')" % display_name)
		return errs
	if allowed_reality_ids.is_empty():
		errs.append("FloorDefinition '%s': allowed_reality_ids is empty" % id)
	if not allowed_reality_ids.has(starting_reality_id):
		errs.append("FloorDefinition '%s': starting_reality_id '%s' is not in allowed_reality_ids" % [id, starting_reality_id])
	return errs
