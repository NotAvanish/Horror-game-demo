class_name Door
extends Interactable
## Door: a hinged door. The node's ORIGIN IS THE HINGE; the panel extends along +Z.
## Exported: door_label, locked, locked_message, open_angle_degrees, open_time,
##   door_color, width/height/thickness, open_sound/close_sound/locked_sound
##   (assign real AudioStreams to replace the placeholders).
## Signals: opened, closed (plus interacted from Interactable).
## Locked doors show locked_message. Unlocking later: set `locked = false`.
## Note: closing the door onto the player may push the player out of the doorway.

signal opened
signal closed

@export var door_label := ""
@export var locked := false
@export var locked_message := "It's locked."
@export var open_angle_degrees := 90.0
@export var open_time := 0.8
@export var door_color := Color(0.25, 0.15, 0.1)
@export var width := 0.98
@export var height := 2.2
@export var thickness := 0.06
@export var open_sound: AudioStream
@export var close_sound: AudioStream
@export var locked_sound: AudioStream

var is_open := false
var _busy := false
var _audio: AudioStreamPlayer3D

func _ready() -> void:
	var panel_pos := Vector3(0.0, height * 0.5, width * 0.5)
	GeometryUtil.add_visual_box(self, Vector3(thickness, height, width), panel_pos, GeometryUtil.material(door_color))
	GeometryUtil.add_collision_box(self, Vector3(thickness, height, width), panel_pos)
	# brass handle
	GeometryUtil.add_visual_box(self, Vector3(thickness + 0.12, 0.05, 0.12), Vector3(0.0, 1.05, width - 0.12), GeometryUtil.material(Color(0.7, 0.55, 0.2)))
	_audio = AudioStreamPlayer3D.new()
	_audio.position = Vector3(0.0, 1.1, width * 0.5)
	_audio.unit_size = 6.0
	add_child(_audio)

func can_interact(_actor: Node) -> bool:
	return enabled and not _busy

func get_interaction_text() -> String:
	var name_text := "door %s" % door_label if door_label != "" else "door"
	if locked:
		return "Try %s" % name_text
	return ("Close " if is_open else "Open ") + name_text

func interact(actor: Node) -> void:
	if locked:
		_play(locked_sound, "locked")
		EventBus.show_message(locked_message, 2.5)
		super.interact(actor)
		return
	_busy = true
	is_open = not is_open
	_play(open_sound if is_open else close_sound, "creak" if is_open else "thud")
	var tween := create_tween().set_trans(Tween.TRANS_SINE)
	tween.tween_property(self, "rotation_degrees:y", open_angle_degrees if is_open else 0.0, open_time)
	tween.finished.connect(_on_tween_finished)
	super.interact(actor)

func _on_tween_finished() -> void:
	_busy = false
	if is_open:
		opened.emit()
	else:
		closed.emit()

func _play(custom: AudioStream, fallback_kind: String) -> void:
	_audio.stream = custom if custom != null else PlaceholderSounds.get_sound(fallback_kind)
	_audio.play()
