class_name RealityAtmosphere
extends WorldEnvironment
## RealityAtmosphere: applies a RealityDefinition's fog and ambient light to the
## WorldEnvironment's Environment resource. Called by GameWorld.
## To change the base look (tonemapping, glow...) edit the Environment resource in
## scenes/main/main.tscn; per-reality values come from the .tres files.

func apply(def: RealityDefinition) -> void:
	if environment == null:
		push_error("RealityAtmosphere: no Environment assigned")
		return
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color.BLACK
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = def.ambient_color
	environment.ambient_light_energy = def.ambient_energy
	environment.fog_enabled = def.fog_enabled
	environment.fog_light_color = def.fog_color
	environment.fog_density = def.fog_density
