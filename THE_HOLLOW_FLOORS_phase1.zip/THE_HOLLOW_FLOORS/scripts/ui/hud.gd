class_name GameHUD
extends CanvasLayer
## GameHUD: crosshair, interaction prompt, and a message line (EventBus messages).
## Public API: bind_sensor(InteractionSensor).
## Prompt size follows GameSettings.prompt_scale (accessibility).
## Phase 2+ adds objectives/inventory widgets as separate scenes under this layer.

var _sensor: InteractionSensor
var _prompt: Label
var _message: Label
var _message_time := 0.0

func _ready() -> void:
	layer = 10
	var root := Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var dot := ColorRect.new()
	dot.color = Color(1, 1, 1, 0.55)
	dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dot.anchor_left = 0.5
	dot.anchor_right = 0.5
	dot.anchor_top = 0.5
	dot.anchor_bottom = 0.5
	dot.offset_left = -2.0
	dot.offset_right = 2.0
	dot.offset_top = -2.0
	dot.offset_bottom = 2.0
	root.add_child(dot)

	_prompt = _make_label(root, 0.5, 0.5, -300.0, 300.0, 30.0, 70.0)
	_message = _make_label(root, 0.0, 1.0, 120.0, -120.0, -190.0, -80.0)
	_message.anchor_right = 1.0
	_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_message.visible = false
	_prompt.visible = false

	EventBus.message_requested.connect(_on_message)
	GameSettings.settings_changed.connect(_apply_font_sizes)
	_apply_font_sizes()

func bind_sensor(sensor: InteractionSensor) -> void:
	_sensor = sensor

func _make_label(parent: Control, ax: float, ay: float, ol: float, orr: float, ot: float, ob: float) -> Label:
	var label := Label.new()
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.anchor_left = ax
	label.anchor_right = ax
	label.anchor_top = ay
	label.anchor_bottom = ay
	label.offset_left = ol
	label.offset_right = orr
	label.offset_top = ot
	label.offset_bottom = ob
	label.add_theme_color_override("font_outline_color", Color.BLACK)
	label.add_theme_constant_override("outline_size", 6)
	parent.add_child(label)
	return label

func _apply_font_sizes() -> void:
	_prompt.add_theme_font_size_override("font_size", int(22.0 * GameSettings.prompt_scale))
	_message.add_theme_font_size_override("font_size", int(20.0 * GameSettings.prompt_scale))

func _on_message(text: String, duration: float) -> void:
	_message.text = text
	_message.visible = true
	_message_time = duration

func _process(delta: float) -> void:
	var shown := false
	if _sensor != null and is_instance_valid(_sensor.current_target):
		var target := _sensor.current_target
		var text := target.get_interaction_text()
		if text != "":
			if target.can_interact(_sensor.actor):
				text = "[E] " + text
			if _prompt.text != text:
				_prompt.text = text
			shown = true
	_prompt.visible = shown
	if _message_time > 0.0:
		_message_time -= delta
		if _message_time <= 0.0:
			_message.visible = false
