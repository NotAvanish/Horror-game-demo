class_name ScreenFader
extends CanvasLayer
## ScreenFader: full-screen black overlay. `await fader.fade_to(1.0, 0.7)` fades to
## black, `fade_to(0.0, 0.7)` back. Used by the Elevator (injected by Main).

var _rect: ColorRect

func _ready() -> void:
	layer = 50
	_rect = ColorRect.new()
	_rect.color = Color(0, 0, 0, 0)
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_rect)
	_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func fade_to(alpha: float, duration: float) -> void:
	var tween := create_tween()
	tween.tween_property(_rect, "color:a", alpha, duration)
	await tween.finished
