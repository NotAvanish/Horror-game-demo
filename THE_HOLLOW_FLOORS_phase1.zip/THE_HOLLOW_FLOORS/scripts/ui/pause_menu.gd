class_name PauseMenu
extends CanvasLayer
## PauseMenu: ESC pauses the game tree. Contains Resume, a few settings and Quit.
## Signals: paused, resumed (Main reacts by releasing/capturing the mouse).
## Settings are written to GameSettings and saved when the menu closes.
## Add a setting: add a var to GameSettings, then one _add_slider/_add_check line below.

signal paused
signal resumed

var is_open := false
var _root: Control

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS   # keep working while the tree is paused
	layer = 80
	_build()
	_root.visible = false

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		if is_open:
			close()
		else:
			open()
		get_viewport().set_input_as_handled()

func open() -> void:
	is_open = true
	_root.visible = true
	get_tree().paused = true
	paused.emit()

func close() -> void:
	GameSettings.apply()
	GameSettings.save_settings()
	is_open = false
	_root.visible = false
	get_tree().paused = false
	resumed.emit()

func _build() -> void:
	_root = Control.new()
	add_child(_root)
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	_root.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	_root.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(400, 0)
	box.add_theme_constant_override("separation", 10)
	center.add_child(box)

	var title := Label.new()
	title.text = "PAUSED"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 36)
	box.add_child(title)

	var resume := Button.new()
	resume.text = "Resume"
	resume.pressed.connect(close)
	box.add_child(resume)

	_add_slider(box, "Mouse sensitivity", 0.2, 3.0, GameSettings.mouse_sensitivity, _set_sensitivity)
	_add_slider(box, "Master volume", 0.0, 1.0, GameSettings.master_volume, _set_master_volume)
	_add_slider(box, "Prompt text size", 0.8, 2.0, GameSettings.prompt_scale, _set_prompt_scale)
	_add_check(box, "Invert mouse Y", GameSettings.invert_mouse_y, _set_invert_y)
	_add_check(box, "Reduced camera shake", GameSettings.reduced_camera_shake, _set_reduced_shake)
	_add_check(box, "Reduced flashing", GameSettings.reduce_flashing, _set_reduce_flashing)

	var quit := Button.new()
	quit.text = "Quit to desktop"
	quit.pressed.connect(get_tree().quit)
	box.add_child(quit)

func _add_slider(parent: Control, label_text: String, min_v: float, max_v: float, value: float, callback: Callable) -> void:
	var label := Label.new()
	label.text = label_text
	parent.add_child(label)
	var slider := HSlider.new()
	slider.min_value = min_v
	slider.max_value = max_v
	slider.step = 0.05
	slider.value = value
	slider.value_changed.connect(callback)
	parent.add_child(slider)

func _add_check(parent: Control, label_text: String, value: bool, callback: Callable) -> void:
	var check := CheckBox.new()
	check.text = label_text
	check.button_pressed = value
	check.toggled.connect(callback)
	parent.add_child(check)

func _set_sensitivity(v: float) -> void:
	GameSettings.mouse_sensitivity = v

func _set_master_volume(v: float) -> void:
	GameSettings.master_volume = v
	GameSettings.apply()

func _set_prompt_scale(v: float) -> void:
	GameSettings.prompt_scale = v
	GameSettings.apply()

func _set_invert_y(v: bool) -> void:
	GameSettings.invert_mouse_y = v

func _set_reduced_shake(v: bool) -> void:
	GameSettings.reduced_camera_shake = v

func _set_reduce_flashing(v: bool) -> void:
	GameSettings.reduce_flashing = v
