extends Node
## GameSettings (autoload)
## Responsibility: player preferences (saved to user://settings.cfg), the master
## volume, and registration of ALL input actions (so no fragile project.godot
## input blocks are needed).
## To change a key: edit INPUT_ACTIONS below.
## To add a setting: add a var, load/save it in the two functions, add a control in
## pause_menu.gd. Nothing else needs to change.
## Signals: settings_changed

signal settings_changed

const SETTINGS_PATH := "user://settings.cfg"

const INPUT_ACTIONS := {
	"move_forward": [KEY_W, KEY_UP],
	"move_back": [KEY_S, KEY_DOWN],
	"move_left": [KEY_A, KEY_LEFT],
	"move_right": [KEY_D, KEY_RIGHT],
	"sprint": [KEY_SHIFT],
	"crouch": [KEY_CTRL, KEY_C],
	"jump": [KEY_SPACE],
	"interact": [KEY_E],
	"flashlight": [KEY_F],
	"pause": [KEY_ESCAPE],
	"debug_toggle": [KEY_F3],
}

var mouse_sensitivity := 1.0        # multiplier on PlayerSettings.mouse_radians_per_pixel
var invert_mouse_y := false
var master_volume := 1.0
var reduced_camera_shake := false
var reduce_flashing := false
var prompt_scale := 1.0
## Developer tools (F3 panel). On in editor/debug runs; in release builds only if
## [dev] enabled=true is added to settings.cfg by hand.
var developer_mode := OS.is_debug_build()

func _ready() -> void:
	_register_inputs()
	load_settings()
	apply()

func _register_inputs() -> void:
	for action in INPUT_ACTIONS:
		if InputMap.has_action(action):
			continue
		InputMap.add_action(action)
		for key in INPUT_ACTIONS[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = key as Key
			InputMap.action_add_event(action, ev)

func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) != OK:
		return   # first run: keep defaults
	mouse_sensitivity = cfg.get_value("controls", "mouse_sensitivity", 1.0)
	invert_mouse_y = cfg.get_value("controls", "invert_mouse_y", false)
	master_volume = cfg.get_value("audio", "master_volume", 1.0)
	reduced_camera_shake = cfg.get_value("accessibility", "reduced_camera_shake", false)
	reduce_flashing = cfg.get_value("accessibility", "reduce_flashing", false)
	prompt_scale = cfg.get_value("accessibility", "prompt_scale", 1.0)
	developer_mode = OS.is_debug_build() or bool(cfg.get_value("dev", "enabled", false))

func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("controls", "mouse_sensitivity", mouse_sensitivity)
	cfg.set_value("controls", "invert_mouse_y", invert_mouse_y)
	cfg.set_value("audio", "master_volume", master_volume)
	cfg.set_value("accessibility", "reduced_camera_shake", reduced_camera_shake)
	cfg.set_value("accessibility", "reduce_flashing", reduce_flashing)
	cfg.set_value("accessibility", "prompt_scale", prompt_scale)
	cfg.set_value("dev", "enabled", developer_mode and not OS.is_debug_build())
	if cfg.save(SETTINGS_PATH) != OK:
		push_warning("GameSettings: could not write %s" % SETTINGS_PATH)

func apply() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(master_volume, 0.0001)))
	settings_changed.emit()
