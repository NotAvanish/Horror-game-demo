class_name Interactable
extends StaticBody3D
## Interactable: the base class / CONTRACT for everything the player can use.
## Contract (override what you need):
##   can_interact(actor) -> bool      false = prompt shown greyed, E does nothing
##   interact(actor)                  do the thing; call super.interact(actor) to emit the signal
##   get_interaction_text() -> String text shown in the prompt (may change over time)
## Signal: interacted(actor)
## Collision: layer 1 (solid world) + layer 2 (interactable). The sensor ray only
## picks bodies on layer 2, so walls still block it.
## Create a new one: docs/ADD_AN_INTERACTABLE.md. Never edit the player for this.

signal interacted(actor: Node)

@export var prompt_text := "Interact"
@export var enabled := true

func _init() -> void:
	collision_layer = 3
	collision_mask = 0

func can_interact(_actor: Node) -> bool:
	return enabled

func interact(actor: Node) -> void:
	interacted.emit(actor)

func get_interaction_text() -> String:
	return prompt_text
