class_name InteractionSensor
extends RayCast3D
## InteractionSensor: the ray from the camera that finds the Interactable you look at
## and calls interact() when the "interact" action (E) is pressed.
## Signals: target_changed(target), interaction_performed(target)
## Public: current_target, actor, sensing_enabled.
## Range is set by PlayerController from PlayerSettings.interaction_distance.
## Dependencies: Interactable.

signal target_changed(target: Interactable)
signal interaction_performed(target: Interactable)

var sensing_enabled := true
var current_target: Interactable
var actor: Node

func _ready() -> void:
	collision_mask = 3
	collide_with_areas = false
	collide_with_bodies = true
	actor = owner   # the Player root (owner of nodes inside player.tscn)

func _physics_process(_delta: float) -> void:
	var found: Interactable = null
	if sensing_enabled and is_colliding():
		found = get_collider() as Interactable
	# A reality rebuild can free the node we were looking at.
	if current_target != null and not is_instance_valid(current_target):
		current_target = null
		target_changed.emit(null)
	if found != current_target:
		current_target = found
		target_changed.emit(found)

func _unhandled_input(event: InputEvent) -> void:
	if not sensing_enabled or not event.is_action_pressed("interact"):
		return
	if current_target == null or not is_instance_valid(current_target):
		return
	if current_target.can_interact(actor):
		current_target.interact(actor)
		interaction_performed.emit(current_target)
