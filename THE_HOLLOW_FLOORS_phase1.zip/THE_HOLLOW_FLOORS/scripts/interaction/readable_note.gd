class_name ReadableNote
extends Interactable
## ReadableNote: a sheet of paper that shows text on the HUD. Example of how small a
## new Interactable can be. Set `note_text` in code or the Inspector.
## Exported: note_text, read_duration.

@export_multiline var note_text := ""
@export var read_duration := 9.0

func _ready() -> void:
	prompt_text = "Read note"
	GeometryUtil.add_visual_box(self, Vector3(0.3, 0.02, 0.22), Vector3.ZERO, GeometryUtil.material(Color(0.85, 0.82, 0.7)))
	GeometryUtil.add_collision_box(self, Vector3(0.4, 0.12, 0.3), Vector3.ZERO)

func interact(actor: Node) -> void:
	if note_text != "":
		EventBus.show_message(note_text, read_duration)
	super.interact(actor)
