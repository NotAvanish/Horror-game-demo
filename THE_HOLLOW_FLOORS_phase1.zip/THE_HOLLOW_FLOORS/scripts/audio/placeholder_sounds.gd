class_name PlaceholderSounds
extends RefCounted
## PlaceholderSounds: generates simple sounds in code so the prototype has audio with
## ZERO asset files. Every component that uses one has an exported AudioStream slot
## (e.g. Flashlight.toggle_sound, Door.open_sound): assign a real file there and the
## placeholder is no longer used. Formal audio events arrive in Phase 2.
## kinds: click, creak, thud, locked, ding, rumble

const RATE := 22050
const DURATIONS := {"click": 0.05, "creak": 0.6, "thud": 0.3, "locked": 0.25, "ding": 1.0, "rumble": 2.0}

static var _cache := {}

static func get_sound(kind: String) -> AudioStreamWAV:
	if _cache.has(kind):
		return _cache[kind]
	var duration: float = DURATIONS.get(kind, 0.1)
	var n := int(RATE * duration)
	var data := PackedByteArray()
	data.resize(n * 2)
	var state := [0.0]
	for i in n:
		var s := _sample(kind, float(i) / RATE, float(i) / n, state)
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 32767.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = data
	if kind == "rumble":
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = n
	_cache[kind] = wav
	return wav

static func _sample(kind: String, t: float, p: float, state: Array) -> float:
	var noise := randf() * 2.0 - 1.0
	match kind:
		"click":
			return noise * 0.5 * (1.0 - p) * (1.0 - p)
		"creak":
			var f := 80.0 + 60.0 * sin(p * TAU * 1.5)
			state[0] += TAU * f / RATE
			return sin(state[0]) * 0.25 * sin(p * PI) + noise * 0.03
		"thud":
			return sin(TAU * 60.0 * t) * exp(-t * 14.0) * 0.8 + noise * exp(-t * 40.0) * 0.3
		"locked":
			return noise * exp(-fmod(t, 0.12) * 60.0) * 0.5
		"ding":
			return sin(TAU * 880.0 * t) * exp(-t * 3.0) * 0.4 + sin(TAU * 1320.0 * t) * exp(-t * 4.0) * 0.2
		"rumble":
			state[0] = state[0] * 0.98 + noise * 0.06
			return state[0] * 2.0
	return 0.0
