extends Node
## ContentRegistry (autoload)
## Responsibility: load every definition Resource from the content folders, validate
## them, and hand them out by stable string ID. Broken content is NEVER silently
## ignored: it is recorded in `errors`, printed with push_error, and shown in the
## debug panel. Definitions that fail validation are not registered.
##
## Content folders (add a .tres here and it is found automatically):
##   res://resources/realities/  -> RealityDefinition
##   res://resources/floors/     -> FloorDefinition
## Dependencies: RealityDefinition, FloorDefinition (class_name scripts).

const REALITY_DIR := "res://resources/realities"
const FLOOR_DIR := "res://resources/floors"

var realities: Dictionary = {}   # String id -> RealityDefinition
var floors: Dictionary = {}      # String id -> FloorDefinition
var errors: PackedStringArray = PackedStringArray()

func _ready() -> void:
	reload()

func reload() -> void:
	realities.clear()
	floors.clear()
	errors = PackedStringArray()

	for res in _scan(REALITY_DIR):
		var def := res as RealityDefinition
		if def == null:
			errors.append("%s is not a RealityDefinition" % res.resource_path)
			continue
		var problems := def.validate()
		if not problems.is_empty():
			errors.append_array(problems)
			continue
		if realities.has(def.id):
			errors.append("Duplicate reality id '%s' (%s)" % [def.id, res.resource_path])
			continue
		realities[def.id] = def

	for res in _scan(FLOOR_DIR):
		var fdef := res as FloorDefinition
		if fdef == null:
			errors.append("%s is not a FloorDefinition" % res.resource_path)
			continue
		var fproblems := fdef.validate()
		if not fproblems.is_empty():
			errors.append_array(fproblems)
			continue
		if floors.has(fdef.id):
			errors.append("Duplicate floor id '%s' (%s)" % [fdef.id, res.resource_path])
			continue
		floors[fdef.id] = fdef

	# Cross references: a floor may only mention realities that exist.
	for floor_def in floors.values():
		var ids: PackedStringArray = floor_def.allowed_reality_ids.duplicate()
		ids.append(floor_def.starting_reality_id)
		for rid in ids:
			if not realities.has(rid):
				errors.append("Floor '%s' references unknown reality '%s'" % [floor_def.id, rid])

	for message in errors:
		push_error("[ContentRegistry] " + message)

func get_reality(id: String) -> RealityDefinition:
	if not realities.has(id):
		push_error("[ContentRegistry] Unknown reality id '%s'. Known: %s" % [id, realities.keys()])
		return null
	return realities[id]

func get_floor(id: String) -> FloorDefinition:
	if not floors.has(id):
		push_error("[ContentRegistry] Unknown floor id '%s'. Known: %s" % [id, floors.keys()])
		return null
	return floors[id]

func _scan(dir_path: String) -> Array[Resource]:
	var out: Array[Resource] = []
	if not DirAccess.dir_exists_absolute(dir_path):
		errors.append("Missing content folder: %s" % dir_path)
		return out
	for file_name in DirAccess.get_files_at(dir_path):
		var clean := file_name.trim_suffix(".remap")   # exported builds add .remap
		if not clean.ends_with(".tres"):
			continue
		var path := dir_path.path_join(clean)
		var res := load(path)
		if res == null:
			errors.append("Could not load resource: %s" % path)
			continue
		out.append(res)
	return out
