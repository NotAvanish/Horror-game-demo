extends Node
## Main: the ONLY place that wires the top-level pieces together (dependency injection).
## It assigns the fader/player to the elevator, binds the HUD to the player's sensor,
## starts the floor, places the player at a validated spawn, and handles mouse capture.
## Exported (assigned in main.tscn): world, player, hud, fader, pause_menu, debug_panel,
##   floor_id (which FloorDefinition to start), start_spawn_id.
## Keep logic out of here: if it is not wiring, it belongs in a component.

@export var world: GameWorld
@export var player: PlayerController
@export var hud: GameHUD
@export var fader: ScreenFader
@export var pause_menu: PauseMenu
@export var debug_panel: DebugPanel
@export var floor_id := "floor_apartment_01"
@export var start_spawn_id := "start"

func _ready() -> void:
	if not _wiring_ok():
		return
	GameState.new_run()
	var floor_def := ContentRegistry.get_floor(floor_id)
	if floor_def == null:
		EventBus.show_message("Cannot start: floor '%s' is missing or invalid. See Output panel." % floor_id, 30.0)
		return
	if not ContentRegistry.errors.is_empty():
		EventBus.show_message("Content errors found (%d). Press F3 or read the Output panel." % ContentRegistry.errors.size(), 10.0)

	hud.bind_sensor(player.sensor)
	world.elevator.fader = fader
	world.elevator.player = player
	debug_panel.setup(world, player)
	pause_menu.paused.connect(_on_paused)
	pause_menu.resumed.connect(_on_resumed)
	debug_panel.visibility_toggled.connect(_on_debug_toggled)

	player.controls_enabled = false
	RealityManager.load_floor(floor_def)
	# The freshly built floor only exists for physics queries after a physics step.
	await get_tree().physics_frame
	await get_tree().physics_frame
	var marker := world.get_spawn(start_spawn_id)
	if marker == null or not world.validate_spawn(start_spawn_id):
		push_error("Main: start spawn '%s' is invalid; placing player in the elevator." % start_spawn_id)
		marker = world.get_spawn("elevator_cab")
	player.teleport_to(marker.global_transform)
	player.controls_enabled = true
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _wiring_ok() -> bool:
	var checks := {"world": world, "player": player, "hud": hud, "fader": fader, "pause_menu": pause_menu, "debug_panel": debug_panel}
	var ok := true
	for key in checks:
		if checks[key] == null:
			push_error("Main: exported node '%s' is not assigned in main.tscn" % key)
			ok = false
	return ok

func _unhandled_input(event: InputEvent) -> void:
	var click := event as InputEventMouseButton
	if click != null and click.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED \
			and not get_tree().paused and not debug_panel.is_open:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _on_paused() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _on_resumed() -> void:
	if not debug_panel.is_open:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _on_debug_toggled(is_open: bool) -> void:
	player.controls_enabled = not is_open
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if is_open else Input.MOUSE_MODE_CAPTURED
