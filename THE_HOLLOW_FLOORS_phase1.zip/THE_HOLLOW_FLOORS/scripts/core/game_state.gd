extends Node
## GameState (autoload)
## Responsibility: story flags and run counters. Nothing else.
## Flags persist across reality changes (RealityManager never clears them).
## Signals: flag_changed(flag, value)
## Used by: RealityManager (visited_<id> flags), future objective/puzzle systems.
## Save/load arrives in Phase 4; `flags` is a plain Dictionary so it will serialise easily.

signal flag_changed(flag: String, value)

var flags: Dictionary = {}
var elevator_rides := 0
## True once any debug tool was used. Phase 4 saves must refuse to write while this is true.
var debug_session := false

func new_run() -> void:
	flags.clear()
	elevator_rides = 0
	debug_session = false

func set_flag(flag: String, value = true) -> void:
	flags[flag] = value
	flag_changed.emit(flag, value)

func get_flag(flag: String, default_value = false):
	return flags.get(flag, default_value)

func has_flag(flag: String) -> bool:
	return flags.get(flag, false) != false
