extends Node
## EventBus (autoload)
## Responsibility: a tiny global signal hub for messages that have no natural owner.
## Signals: message_requested(text, duration)
## Use: EventBus.show_message("Hello", 3.0)  -- the HUD displays it.
## Extend: add new signals here ONLY if two unrelated systems need to talk.
## Otherwise connect signals directly between the two systems.

signal message_requested(text: String, duration: float)

func show_message(text: String, duration: float = 3.0) -> void:
	message_requested.emit(text, duration)
