class_name DebugPanel
extends CanvasLayer
## DebugPanel (F3, developer mode only): live info + safe test tools.
## Shows: FPS, draw calls, memory, floor/reality ids, elevator state, player position,
##   the object you are looking at, story flags, content validation errors.
## Tools: switch reality (then teleports to "start"), teleport to any spawn,
##   reset test run, reload level, show a test message.
## Any tool use sets GameState.debug_session = true (Phase 4 saves must refuse then).
## Disabled entirely unless GameSettings.developer_mode is true.
## Add a tool: add a button in _build_ui() and a handler below. Document it in docs/DEBUGGING.md.
## Signal: visibility_toggled(is_open)

signal visibility_toggled(is_open: bool)

var is_open := false

var _world: GameWorld
var _player: PlayerController
var _panel: PanelContainer
var _info: Label
var _errors: Label
var _spawn_list: OptionButton
var _timer := 0.0

func setup(world: GameWorld, player: PlayerController) -> void:
	_world = world
	_player = player
	if _world != null:
		_world.spawns_changed.connect(_refresh_spawns)

func _ready() -> void:
	layer = 90
	if not GameSettings.developer_mode:
		set_process(false)
		set_process_unhandled_input(false)
		return
	_build_ui()
	_panel.visible = false

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("debug_toggle"):
		is_open = not is_open
		_panel.visible = is_open
		if is_open:
			_refresh_spawns()
			_update_info()
		visibility_toggled.emit(is_open)
		get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
	if not is_open:
		return
	_timer += delta
	if _timer >= 0.25:
		_timer = 0.0
		_update_info()

func _build_ui() -> void:
	_panel = PanelContainer.new()
	_panel.position = Vector2(10, 10)
	add_child(_panel)
	var box := VBoxContainer.new()
	_panel.add_child(box)
	_info = _small_label()
	box.add_child(_info)

	box.add_child(_small_label("-- Switch reality (rebuilds floor, teleports to start) --"))
	var reality_row := HBoxContainer.new()
	box.add_child(reality_row)
	for rid in ContentRegistry.realities.keys():
		var b := Button.new()
		b.text = str(rid)
		b.pressed.connect(_on_reality_pressed.bind(str(rid)))
		reality_row.add_child(b)

	box.add_child(_small_label("-- Teleport to spawn --"))
	var tele_row := HBoxContainer.new()
	box.add_child(tele_row)
	_spawn_list = OptionButton.new()
	tele_row.add_child(_spawn_list)
	var go := Button.new()
	go.text = "Go"
	go.pressed.connect(_on_teleport_pressed)
	tele_row.add_child(go)

	box.add_child(_small_label("-- Run --"))
	var run_row := HBoxContainer.new()
	box.add_child(run_row)
	for entry in [["Reset test run", _on_reset_pressed], ["Reload level", _on_reload_pressed], ["Test message", _on_test_message_pressed]]:
		var rb := Button.new()
		rb.text = entry[0]
		rb.pressed.connect(entry[1])
		run_row.add_child(rb)

	_errors = _small_label()
	box.add_child(_errors)

func _small_label(text := "") -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 13)
	return l

func _refresh_spawns() -> void:
	if _spawn_list == null or _world == null:
		return
	_spawn_list.clear()
	for id in _world.get_spawn_ids():
		_spawn_list.add_item(id)

func _update_info() -> void:
	var fd := RealityManager.floor_definition
	var floor_id := fd.id if fd != null else "-"
	var looking := "-"
	var pos := Vector3.ZERO
	if _player != null:
		pos = _player.global_position
		if is_instance_valid(_player.sensor.current_target):
			looking = str(_player.sensor.current_target.name)
	var elevator_state := "-"
	if _world != null and _world.elevator != null:
		elevator_state = Elevator.State.keys()[_world.elevator.state]
	_info.text = "FPS %d | draw calls %d | mem %.0f MB\nFloor: %s | Reality: %s | Elevator: %s\nPlayer: (%.1f, %.1f, %.1f)\nLooking at: %s\nFlags: %s | rides: %d%s" % [
		Engine.get_frames_per_second(),
		Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),
		Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0,
		floor_id, RealityManager.current_reality_id, elevator_state,
		pos.x, pos.y, pos.z, looking,
		GameState.flags.keys(), GameState.elevator_rides,
		"\n[DEBUG SESSION - saves disabled]" if GameState.debug_session else ""]
	if ContentRegistry.errors.is_empty():
		_errors.text = "Content validation: OK"
	else:
		_errors.text = "CONTENT ERRORS:\n" + "\n".join(ContentRegistry.errors)

func _teleport(id: String) -> void:
	if _world == null or _player == null:
		return
	var marker := _world.get_spawn(id)
	if marker == null:
		push_error("DebugPanel: unknown spawn '%s'" % id)
		return
	GameState.debug_session = true
	_player.teleport_to(marker.global_transform)

func _on_teleport_pressed() -> void:
	if _spawn_list.item_count > 0:
		_teleport(_spawn_list.get_item_text(_spawn_list.selected))

func _on_reality_pressed(rid: String) -> void:
	if _world != null and _world.elevator.state != Elevator.State.OPEN:
		return   # never rebuild mid-trip
	GameState.debug_session = true
	if RealityManager.set_reality_immediate(rid):
		await get_tree().physics_frame
		await get_tree().physics_frame
		_teleport("start")

func _on_reset_pressed() -> void:
	if _world != null and _world.elevator.state != Elevator.State.OPEN:
		return
	GameState.new_run()
	GameState.debug_session = true
	RealityManager.load_floor(RealityManager.floor_definition)
	await get_tree().physics_frame
	await get_tree().physics_frame
	_teleport("start")

func _on_reload_pressed() -> void:
	get_tree().reload_current_scene()

func _on_test_message_pressed() -> void:
	EventBus.show_message("Debug test message. Everything is fine.", 3.0)
