# Conventions
- Files/folders `snake_case`; classes `PascalCase` (`class_name`); signals past tense (`opened`); private members `_underscore`.
- IDs are lowercase strings (`normal`, `floor_apartment_01`) and never change once used.
- Tunable numbers go in exported vars or Resources, not magic numbers in logic.
- One responsibility per script; talk through signals/exports/injection, avoid `get_node("../..")`.
- New autoloads only if truly global.
- Before committing: run the game, follow `tests/test_checklist.md`, update docs and `CHANGELOG.md`.
- Never document a feature that does not exist yet.
